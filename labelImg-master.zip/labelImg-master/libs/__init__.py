__version_info__ = ('1', '8', '2')
__version__ = '.'.join(__version_info__)
